#!/bin/bash
mkdir spi-con
cp -r hdl/spi/* spi-con/
cp setup/spi.do spi-con/
