This project draws on 2 separate projects. The SD Controller comes from
opencores and the NAND controller comes from Lattice Semiconductor. In
order to maintain transparency, and for documenting where we changed
things, these projects have been added in subfolders.
